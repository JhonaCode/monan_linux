These are #include files used in mpas_ocn_regional_stats.F.
