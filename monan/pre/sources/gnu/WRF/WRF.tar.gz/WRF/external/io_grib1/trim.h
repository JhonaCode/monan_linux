char *trim (char *str);

