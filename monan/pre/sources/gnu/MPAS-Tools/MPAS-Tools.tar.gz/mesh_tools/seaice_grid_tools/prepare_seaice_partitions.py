#!/usr/bin/env python
from mpas_tools.seaice.partition import prepare_partitions

prepare_partitions()
