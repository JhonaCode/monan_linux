Main Authors
============
* Xylar Asay-Davis
* Michael Duda
* Matthew Hoffman
* Douglas Jacobsen

Contributors
============
* Riley X. Brady
* Miles Curry
* Amrapalli Garanaik
* Dom Heinzeller
* Trevor Hillebrand
* Joseph Kennedy
* William Lipscomb
* Mark Petersen
* Stephen Price
* Todd Ringler
* Juan Saenz
* Adrian Turner
* Luke Van Roekel
* Phillip J. Wolfram
* Tong Zhang

For a list of all the contributions:
https://github.com/MPAS-Dev/MPAS-Tools/graphs/contributors
