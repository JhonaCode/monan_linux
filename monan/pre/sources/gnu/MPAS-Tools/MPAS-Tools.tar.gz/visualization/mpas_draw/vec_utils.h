using namespace std;

double r8_huge ( );
double r8vec_max ( int n, double r8vec[], double missing_value );
double r8vec_min ( int n, double r8vec[], double missing_value );
void r8vec_min_max ( int n, double r8vec[], double &min, double&max, double missing_value );
